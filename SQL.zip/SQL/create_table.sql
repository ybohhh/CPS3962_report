CREATE DATABASE FraudDetectionDB1;
USE FraudDetectionDB1;

CREATE TABLE CreditCardTransactions1 (
    id INT PRIMARY KEY AUTO_INCREMENT,
    time_sec DOUBLE,
    amount DECIMAL(10, 2),
    v1 DOUBLE, v2 DOUBLE, v3 DOUBLE,  
    v4 DOUBLE, v5 DOUBLE, v6 DOUBLE,
    v7 DOUBLE, v8 DOUBLE, v9 DOUBLE, v10 DOUBLE,
    class BOOLEAN
);

UPDATE creditcardtransactions1
SET class = 1
WHERE id IN (
    SELECT id FROM (
        SELECT id FROM creditcardtransactions1
        WHERE class = 0
        ORDER BY RAND()
        LIMIT 44
    ) AS temp
);

CREATE TABLE Alerts (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id INT,
    alert_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    alert_status VARCHAR(20) DEFAULT 'Pending',
    message TEXT,
    FOREIGN KEY (transaction_id) REFERENCES CreditCardTransactions1(id)
);

UPDATE Alerts SET alert_status = 'Reviewed' WHERE alert_id = 123;


SELECT a.alert_id, a.alert_time, a.alert_status, c.amount, c.class
FROM Alerts a
JOIN CreditCardTransactions1 c ON a.transaction_id = c.id
WHERE a.alert_status = 'Pending';

CREATE TABLE Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    role ENUM('admin', 'reviewer', 'customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE AdminActions (
    action_id INT AUTO_INCREMENT PRIMARY KEY,
    alert_id INT,
    admin_id INT,
    action_type VARCHAR(50),  -- e.g., 'Marked as Reviewed'
    action_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    comment TEXT,
    FOREIGN KEY (alert_id) REFERENCES Alerts(alert_id),
    FOREIGN KEY (admin_id) REFERENCES Users(user_id)
);







