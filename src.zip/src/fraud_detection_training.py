import pandas as pd
import mysql.connector
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from imblearn.over_sampling import SMOTE
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

# Step 1: 数据库读取
db_config = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "cps3962",
    "database": "frauddetectiondb1"
}
conn = mysql.connector.connect(**db_config)
query = "SELECT * FROM CreditCardTransactions1"
df = pd.read_sql(query, conn)
conn.close()

# Step 2: 特征和标签
X = df.drop(columns=["id", "class"], errors="ignore")
y = df["class"]

# Step 3: 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 4: 划分数据
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.3, random_state=42, stratify=y
)

# Step 5: SMOTE 增强
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_train, y_train)

# Step 6: 训练随机森林
model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
model.fit(X_resampled, y_resampled)

# Step 7: 预测与评估
y_pred = model.predict(X_test)

print("🔍 Classification Report:")
print(classification_report(y_test, y_pred))
print("✅ Accuracy:", accuracy_score(y_test, y_pred))

# Step 8: 可视化混淆矩阵
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=['Normal', 'Fraud'], yticklabels=['Normal', 'Fraud'])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix (Random Forest + SMOTE)")
plt.tight_layout()
plt.show()
