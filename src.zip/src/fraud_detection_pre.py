import pandas as pd
import mysql.connector
import warnings
warnings.filterwarnings("ignore")

# 读取数据
df = pd.read_csv("D:/MATH/CPS3962/archive/creditcard.csv")
df = df[['Time', 'Amount'] + [f'V{i}' for i in range(1, 11)] + ['Class']]
df.columns = ['time_sec', 'amount'] + [f'v{i}' for i in range(1, 11)] + ['class']

# 可选：取样测试
df = df.sample(n=5000, random_state=42)

# 数据库连接信息
db_config = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "cps3962",  # 替换为你自己的密码
    "database": "frauddetectiondb1"
}

# 建立连接
conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# ⚠️ 可选：先清空旧表数据
cursor.execute("DELETE FROM CreditCardTransactions1")
conn.commit()

# 插入数据
print("[写入数据库] 插入中...")
for _, row in df.iterrows():
    sql = """
    INSERT INTO CreditCardTransactions1 (
        time_sec, amount, v1, v2, v3, v4, v5,
        v6, v7, v8, v9, v10, class
    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    values = tuple(row)
    cursor.execute(sql, values)

conn.commit()
cursor.close()
conn.close()
print("[✅ 完成] 数据已成功写入数据库！")
